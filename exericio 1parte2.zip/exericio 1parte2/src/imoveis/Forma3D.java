package imoveis;

public interface Forma3D {

    public Double getVolume();
}
