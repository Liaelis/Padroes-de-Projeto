package imoveis;

public interface FormaGeometrica {

    public Double getArea();
}
