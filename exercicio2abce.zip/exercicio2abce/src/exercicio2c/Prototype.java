package exercicio2c;

public interface Prototype<T>{

    T clone();
}
