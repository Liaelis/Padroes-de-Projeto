package exercicio32;

public interface Valoravel {

    Double getValor();
}
