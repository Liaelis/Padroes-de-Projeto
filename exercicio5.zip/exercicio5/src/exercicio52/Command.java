package exercicio52;

public interface Command {

    void execute();
}
