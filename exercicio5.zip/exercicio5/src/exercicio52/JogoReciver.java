package exercicio52;

public interface JogoReciver {

    void botãoA();
    void botãoB();
    void direcionalCima();
    void direcionalBaixo();
    void direcionalEsquerda();
    void direcionalDireita();
}
