package exercicio51;

public interface Observer {

    void notify(Observable observable);
}
