package exercicio51;

import sistema_bancario.Conta;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.CheckedOutputStream;

public class Serasa implements Observer{

    private List<Conta> negativados = new ArrayList<Conta>();

    @Override
    public void notify(Observable observable) {
        if(observable instanceof Conta &&  ((Conta) observable).getSaldo()<0.0 ){
            this.negativados.add((Conta) observable);
        }else if(observable instanceof Conta && ((Conta) observable).getSaldo()>=0.0){
            this.negativados.remove(observable);
        }

    }
}
