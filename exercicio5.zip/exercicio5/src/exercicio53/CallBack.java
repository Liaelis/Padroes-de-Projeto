package exercicio53;

public interface CallBack {

    void callBack(Object retorno);
}
