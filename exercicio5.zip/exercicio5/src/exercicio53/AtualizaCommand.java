package exercicio53;

public class AtualizaCommand {
}
