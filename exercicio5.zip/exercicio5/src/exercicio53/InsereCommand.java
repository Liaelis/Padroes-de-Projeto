package exercicio53;

public class InsereCommand {
}
