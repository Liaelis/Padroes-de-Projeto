package exercicio53;

public class LEIAME {
}
