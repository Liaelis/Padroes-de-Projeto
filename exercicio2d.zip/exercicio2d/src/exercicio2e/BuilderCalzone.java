package exercicio2e;

public class BuilderCalzone implements Builder {


    @Override
    public void fazMassa() {

    }

    @Override
    public void queijo() {

    }

    @Override
    public void queijoParmezao() {

    }

    @Override
    public void queijoGorgonzola() {

    }

    @Override
    public void molhoTomate() {

    }

    @Override
    public void carneGado() {

    }

    @Override
    public void calabresa() {

    }

    @Override
    public void bacon() {

    }

    @Override
    public void frango() {

    }

    @Override
    public void batataPalha() {

    }

    @Override
    public void milho() {

    }
}
