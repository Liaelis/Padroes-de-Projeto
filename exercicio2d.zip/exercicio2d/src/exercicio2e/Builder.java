package exercicio2e;

public interface Builder {

    void fazMassa();

    void queijo();

    void queijoParmezao();

    void queijoGorgonzola();

    void molhoTomate();

    void carneGado();

    void calabresa();

    void bacon();

    void frango();

    void batataPalha();

    void milho();
}
