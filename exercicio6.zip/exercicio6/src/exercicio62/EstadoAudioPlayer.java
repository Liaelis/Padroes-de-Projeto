package exercicio62;

public interface EstadoAudioPlayer  {

    EstadoAudioPlayer play();
    EstadoAudioPlayer next();
    EstadoAudioPlayer previous();
    EstadoAudioPlayer lock();

}
